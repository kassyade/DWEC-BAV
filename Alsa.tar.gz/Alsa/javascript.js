let inputOrigen = document.getElementById("origen")
let inputDestino = document.getElementById("destino")
let bttnCambio = document.getElementById("swapButton")
let buttnBuscar = document.getElementById("buscar")
let dateIda = document.getElementById("fechaIda")
let dateVuelta = document.getElementById("fechaVuelta")
let chkBxSoloIda=document.getElementById("soloIda")
let resOrigen = document.getElementById("resOrigen")
let resDestino = document.getElementById("resDestino")
let resFechaIda = document.getElementById("resFechaIda")
let resFechaVuelta = document.getElementById("resFechaVuelta")
let resSoloIda = document.getElementById("resSoloIda")
let formularioResultado={
resOrigen,resDestino,resFechaIda,resFechaVuelta,resSoloIda
}


//valores
let isSoloIda=false
let formulario={}

//FECHA MINIMA DE DATE 
let dateActual = new Date()
let dia =dateActual.getDate()
let mes = dateActual.getMonth()+1//empueza desde 0
let año = dateActual.getFullYear()
let fechaMinima = `${año}-${'0'+mes}-${'0'+dia}`
dateIda.setAttribute("min",fechaMinima)
//console.log(fechaMinima)
//FECHA MINIMA DE VUELTA 

dateIda.addEventListener("change",()=>{
        let fechaMinimaVuelta = dateIda.value 
        dateVuelta.setAttribute("min",fechaMinimaVuelta)



})




bttnCambio.addEventListener("click",
    ()=>{
        //console.log("cabio")
               //valores de input
               let origen = inputOrigen.value
               let destino= inputDestino.value

               inputOrigen.value=destino 
               inputDestino.value=origen

            //console.log("cambio realizado")

    }
)



//BOTON BUSCAR
buttnBuscar.addEventListener("click"
    ,(e)=>{
        let isValido = false
        e.preventDefault()
        //valores de input
        let origen = inputOrigen.value
        let destino= inputDestino.value
        let ida = dateIda.value
        let vuelta = dateVuelta.value

        //console.log(dia,mes,año)
        //console.log("boton")
        //console.log(origen,destino)
        if(origen==="" || destino===""){
            alert("campos origen o destino sin rellenar  ")
           
        }else{
                let numIda= Date.parse(ida)
                let numVuelta= Date.parse(vuelta)
                //console.log(numIda,numVuelta)
                if(isSoloIda===false){
                    if(numIda>numVuelta){
                        alert("error con las fechas")
                        isValido=false
                    }else{
                        if(isSoloIda===true){
                            formulario = {origen,destino,ida}
                        
        
                       }else{
                           formulario = {origen,destino,ida,vuelta}
                        
        
                       }
                        isValido=true
                    }
                }else{
                    if(isSoloIda===true){
                        formulario = {origen,destino,ida}
                    
    
                   }else{
                       formulario = {origen,destino,ida,vuelta}
                    
    
                   }
                    isValido=true
                }

               //console.log(dateIda.valueAsDate)

        }
        //console.log(formulario)
        if(isValido===true){
            //console.log("es valido")
            formularioResultado.resOrigen.innerHTML=formulario.origen
            formularioResultado.resDestino.innerHTML=formulario.destino
            formularioResultado.resFechaIda.innerHTML=formulario.ida
            isSoloIda===true ? formularioResultado.resFechaVuelta.innerHTML="---": formularioResultado.resFechaVuelta.innerHTML=formulario.vuelta
            isSoloIda===true ? formularioResultado.resSoloIda.innerHTML="Solo ida":formularioResultado.resSoloIda.innerHTML="Vuelta incluida"
        }



    }
)

//CHECKBOX
chkBxSoloIda.addEventListener("click",
    ()=>{
        isSoloIda===false ? isSoloIda=true : isSoloIda=false
        //console.log(isSoloIda)
        if(isSoloIda){
            dateVuelta.setAttribute("disabled",true)
        }else{
            dateVuelta.removeAttribute("disabled")
        }

    }   
)

function cambiarValor(campo,valor){
    campo.innerHTML=valor
    
}