let boton=document.getElementById("idAnadir")
let lista = document.getElementById("lista")
let elementos=[]
let cantidadElementos =0

if (cantidadElementos===0){
    elementos.push("Azúcar","Cerveza","Pan","Patatas")
    dibujarLista()
    
}

boton.addEventListener("click",anadirElemento)


function anadirElemento(){
    
    let input = document.getElementById("idArticulo")
    let valorInput =input.value
    if(valorInput===""){
        alert("valor input vacio")
    }else{
        elementos.push(valorInput)
        // Borrar elementos de la lista
        borrarLista()
    
        //Añadir lista completa
        dibujarLista()
        input.value=""
    }

}

function borrarLista(){

    lista.innerHTML=""


}
function dibujarLista(){
//console.log(elementos.sort())
//console.log(elementos)


crearli(elementos.sort())



}
function crearli (arrayElementos){
    //console.log(arrayElementos)

    arrayElementos.forEach(
        (valor)=>{
            
            let li = document.createElement("li")
            li.innerHTML=valor
            lista.appendChild(li)
            li.id=valor

            li.addEventListener("click",
                ()=>{
                    //console.log(li)
                    li.remove()
                }
            )



        }
    )




    
    
}
